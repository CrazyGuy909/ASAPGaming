local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("You have a door, you have EMP poof no more door")
CHALLENGE:SetIcon("battlepass/tiers.png")
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Craft :goal EMP Dart Guns")
CHALLENGE:SetFinishedDesc("BLUEEEEE")
CHALLENGE:SetID("craft_hgahga")

CHALLENGE:AddHook("OnItemCrafted", function(self, _ply, ply, item)
    if ply == _ply and item == "tfa_cso_dartpistol_emp" then
        self:AddProgress(1)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)
----------------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("ZOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOM")
CHALLENGE:SetIcon("battlepass/tiers.png")
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Craft :goal Speed Suits")
CHALLENGE:SetFinishedDesc("Zooming down the street")
CHALLENGE:SetID("craft_hscrcher")

CHALLENGE:AddHook("OnItemCrafted", function(self, _ply, ply, item)
    if ply == _ply and item == "armor_speedsuit" then
        self:AddProgress(1)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)
----------------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Craft a Magnum Launcher Expert")
CHALLENGE:SetIcon("battlepass/tiers.png")
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Craft a Magnum Launcher Expert")
CHALLENGE:SetFinishedDesc("Sexy gun very sexy")
CHALLENGE:SetID("craft_gauss")

CHALLENGE:AddHook("OnItemCrafted", function(self, _ply, ply, item)
    if ply == _ply and item == "tfa_cso_magnumlauncher_gs18" then
        self:AddProgress(1)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)
----------------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Craft a Stealth Guardian Armor")
CHALLENGE:SetIcon("battlepass/tiers.png")
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Craft a Stealth Guardian Armor")
CHALLENGE:SetFinishedDesc("Fast and Stronk")
CHALLENGE:SetID("craft_x35")

CHALLENGE:AddHook("OnItemCrafted", function(self, _ply, ply, item)
    if ply == _ply and item == "armor_sgasga" then
        self:AddProgress(1)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)
----------------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Wait you're telling me I don't need a lockpick anymore?")
CHALLENGE:SetIcon("battlepass/tiers.png")
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Craft :goal EMP Stars")
CHALLENGE:SetFinishedDesc("Time to open some doors.")
CHALLENGE:SetID("craft_empstar")

CHALLENGE:AddHook("OnItemCrafted", function(self, _ply, ply, item)
    if ply == _ply and item == "swep_arcstar" then
        self:AddProgress(1)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)
----------------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Best Friends Forever")
CHALLENGE:SetIcon("battlepass/tiers.png")
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Buy a permanent weapon from the permanent weapon gun shops")
CHALLENGE:SetFinishedDesc("This metal buddy will be your friend until your death (Logically)")
CHALLENGE:SetID("bff_wep")

CHALLENGE:AddHook("OnBuyPermanentWeapon", function(self, _ply, ply, item)
    if ply == _ply then
        self:AddProgress(1)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)