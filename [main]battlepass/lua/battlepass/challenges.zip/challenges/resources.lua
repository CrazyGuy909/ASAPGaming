local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Gather Quartz from the mines")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Quartz!")
CHALLENGE:SetFinishedDesc("Damn you went to minecraft nether to get this?")
CHALLENGE:SetID("asap_quartz")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Quartz") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)



-----------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Gather Uranium from the ocean")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Uranium!")
CHALLENGE:SetFinishedDesc("Hopefully you didn't get radiation poisoning...")
CHALLENGE:SetID("asap_uranium")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Uranium") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)






-----------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Gather Palm Logs")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Palm Logs!")
CHALLENGE:SetFinishedDesc("Good job")
CHALLENGE:SetID("asap_palm")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Palm Logs") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)


-----------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Collect Limonite from the mines")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Limonite!")
CHALLENGE:SetFinishedDesc("ah yes a lemon")
CHALLENGE:SetID("asap_limonite")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Limonite") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)


-----------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Gather Silver from the mines")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Silver!")
CHALLENGE:SetFinishedDesc("Lots and lots of silver")
CHALLENGE:SetID("asap_silver")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Silver") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)
-----------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Gather Andesite from the mines")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Andesite!")
CHALLENGE:SetFinishedDesc("You gathered enough Andesite")
CHALLENGE:SetID("asap_andesite")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Andesite") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)
-----------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Gather Lithium from the mines")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Lithium!")
CHALLENGE:SetFinishedDesc("You gathered enough Lithium")
CHALLENGE:SetID("asap_lithium")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Lithium") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)



-----------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Gather Amethyst from the mines")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Amethyst!")
CHALLENGE:SetFinishedDesc("pooorpleeeeeeeeeeee")
CHALLENGE:SetID("asap_amethyst")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Amethyst") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)

-----------------------------------------------------------------------------------------
local CHALLENGE = BATTLEPASS:CreateTemplateChallenge()
CHALLENGE:SetName("Gather Rock from the mines")
CHALLENGE:SetIcon("battlepass/tiers.png") -- <- ??
CHALLENGE:SetDesc("")
CHALLENGE:SetProgressDesc("Gather :goal Rock!")
CHALLENGE:SetFinishedDesc("Thats a lot of fucking rocks")
CHALLENGE:SetID("asap_rock")

CHALLENGE:AddHook("asapmining_hitOre", function(self, owner, ply, typ, amt)
    if (owner ~= ply) then return end

    if (typ == "Rock") then
        self:AddProgress(amt)
        self:NetworkProgress()
    end
end)

BATTLEPASS:RegisterChallenge(CHALLENGE)




