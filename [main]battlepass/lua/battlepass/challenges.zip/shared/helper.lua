function BATTLEPASS:Replace(str, tbl)
    for i, v in pairs(tbl) do
        str = str:Replace(":" .. i, v)
    end

    return str
end

function BATTLEPASS:SetupPass(ply)
    ply.BattlePass = ply.BattlePass or {}
    ply.BattlePass.ClaimedItems = ply.BattlePass.ClaimedItems or {}

    ply.BattlePass.Owned = ply.BattlePass.Owned or {
        owned = false,
        tier = 0,
        progress = 0
    }
end

function BATTLEPASS:CreateChallengeFromID(id)
    return table.Copy(self.Challenges[id])
end

function BATTLEPASS:AddTier(ply, amt)
    self:SetupPass(ply)
    ply.BattlePass.Owned.tier = ply.BattlePass.Owned.tier + amt

    if (SERVER) then
        self.Database:SavePlayer(ply)
        net.Start("BATTLEPASS.AddTier")
        net.WriteUInt(amt, 8)
        net.Send(ply)
    elseif (CLIENT) then
        local msg = "You have leveled up your Battle Pass to level " .. ply.BattlePass.Owned.tier
        notification.AddLegacy(msg, NOTIFY_GENERIC, 5)
        chat.AddText(XeninUI.Theme.Accent, "[BATTLE PASS] ", color_white, msg)
        XeninUI:Notify("Please claim your new rewards in the Battle Pass!", LocalPlayer(), 5)
        chat.AddText(XeninUI.Theme.Accent, "[BATTLE PASS] ", color_white, "Please claim your new rewards in the Battle Pass!")
    end
end

function BATTLEPASS:SetTier(ply, amt)
    self:SetupPass(ply)
    ply.BattlePass.Owned.tier = amt
end

function BATTLEPASS:AddProgress(ply, amt)
    self:SetupPass(ply)
    ply.BattlePass.Owned.progress = ply.BattlePass.Owned.progress + amt

    if (ply.BattlePass.Owned.progress >= 10) then
        self:AddTier(ply, 1)
        self:AddProgress(ply, -10)
    end

    if (SERVER) then
        self.Database:SavePlayer(ply)
    end
end

function BATTLEPASS:SetProgress(ply, amt)
    self:SetupPass(ply)
    ply.BattlePass.Owned.progress = amt

    if (SERVER) then
        self.Database:SavePlayer(ply)
    end
end

function BATTLEPASS:SetOwned(ply, state)
    self:SetupPass(ply)
    ply.BattlePass.Owned.owned = state

    if (SERVER) then
        self.Database:SavePlayer(ply)
    end
end

function BATTLEPASS:CreateItem(mdl, locked)
    return {
        display = mdl,
        func = BATTLEPASS.Unlock.Unbox,
        extra = {
            id = mdl,
            locked = locked or false
        }
    }
end

hook.Add("BU3.ItemsLoaded", "FixupBP", function()
    for k, v in pairs(BATTLEPASS.Pass.rewards.free) do
        for _, it in pairs(v) do
            local item = BU3.Items.Items[it.display]
            if not item then continue end
            it.name = item.name
            it.tooltip = item.name
            if CLIENT then
                //it.color = BU3.Items.RarityToColor[item.itemColorCode]
            end
        end
    end

    for k, v in pairs(BATTLEPASS.Pass.rewards.premium) do
        for _, it in pairs(v) do
            local item = BU3.Items.Items[it.display]
            if not item then continue end
            it.name = item.name
            it.tooltip = item.name
            if CLIENT then
                //v.color = BU3.Items.RarityToColor[item.itemColorCode]
            end
        end
    end
end)

function BATTLEPASS:CreateChallenge(challengeId, goal, reward, name)
    return {
        id = challengeId,
        goal = goal,
        reward = reward,
        name = name
    }
end

function BATTLEPASS:CreateCategory(id, name, tbl)
    local newTbl = {
        name = name,
        id = id,
        challenges = {}
    }

    for i, v in pairs(tbl) do
        local temp = v
        temp.uid = nil
        newTbl.challenges[v.uid] = temp
    end

    return newTbl
end

function BATTLEPASS:AddPass(pid, data)
    self.Pass = {
        id = pid,
        name = data.name,
        ends = data.ends,
        rewards = {
            free = data.rewards.free or {},
            premium = data.rewards.premium or {}
        },
        tiers = data.tiers,
        challenges = data.challenges
    }

    local stars = 0
    for k, group in pairs(data.challenges) do
        for k, v in pairs(group) do
            for i = 1, #v.reward do
                stars = stars + v.reward[i]
            end
        end
    end

    MsgN(stars)
    return self.Pass[pid]
end

function BATTLEPASS:ClaimItem(ply, premium, tier, index)
    if (premium and not ply.BattlePass.Owned.owned) then return end
    if (ply.BattlePass.Owned.tier < tier) then return end -- fuck off niggas
    ply.BattlePass.ClaimedItems = ply.BattlePass.ClaimedItems or {}
    local hasClaimedItem = ply.BattlePass.ClaimedItems[tier]

    if (hasClaimedItem) then
        if (premium) then
            hasClaimedItem = hasClaimedItem.premium and hasClaimedItem.premium[index]
        else
            hasClaimedItem = hasClaimedItem.free
        end
    end

    if (hasClaimedItem) then return end
    local item = BATTLEPASS.Pass.rewards[premium and "premium" or "free"][tier][index]

    if (premium) then
        ply.BattlePass.ClaimedItems[tier].premium[index] = true
    else
        ply.BattlePass.ClaimedItems[tier].free = true
    end

    item.func(ply, item)

    if (SERVER) then
        BATTLEPASS.Database:SaveClaim(ply, premium, tier, index)
    end
end

function BATTLEPASS:CanBuyPass(ply)
    return ply:CanAffordStoreCredits(BATTLEPASS.Config.PassPrice)
end

function BATTLEPASS:CanBuyTiers(ply, amt)
    if (not ply.BattlePass.Owned.owned) then return end

    return ply:CanAffordStoreCredits(BATTLEPASS.Config.TierPrice)
end
