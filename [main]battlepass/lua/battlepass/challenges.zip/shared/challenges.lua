local CHALLENGE = {}
CHALLENGE.__index = CHALLENGE

function CHALLENGE.New(player, name, desc, icon, uid, progress, goal)
    local self = setmetatable({}, CHALLENGE)
    self.name = name
    self.desc = desc
    self.icon = icon
    self.uid = uid
    self.stage = 1
    self.progress = progress or 0

    --self.goal = goal or 10
    self.goal = tonumber(goal) and {goal} or istable(goal) and goal or {10}

    self.player = player

    if (player) then
        self.pid = player:SteamID64()
    end

    self.hooks = {}
    table.sort(self.goal, function(a, b) return a > b end)

    return self
end

function CHALLENGE:SetName(name)
    self.name = name
end

function CHALLENGE:GetName()
    return self.name
end

function CHALLENGE:SetDesc(desc)
    self.desc = desc
end

function CHALLENGE:GetDesc()
    return self.desc
end

function CHALLENGE:SetIcon(icon)
    self.icon = icon
end

function CHALLENGE:GetIcon()
    return self.icon
end

function CHALLENGE:SetID(id)
    self.uid = id
end

function CHALLENGE:GetID()
    return self.uid
end

function CHALLENGE:SetStage(stage)
    self.stage = stage
end

function CHALLENGE:GetStage()
    return self.stage
end

function CHALLENGE:CheckStage()
end

function CHALLENGE:SetFormatting(func)
    self.format = func
end

function CHALLENGE:GetFormatting(...)
    return self.format(...)
end

function CHALLENGE:SetProgress(amt, calculateStage)
    local startProgress = self.progress or 0
    self.progress = amt

    if (calculateStage) then
        self:CalculateStage()
    end

    if (SERVER and startProgress < self:GetGoal()) then
        self:SaveThink()
    end
end

function CHALLENGE:GetProgress()
    return self.progress
end

function CHALLENGE:SaveThink()
    self:Save()
end

function CHALLENGE:SetFinishedDesc(str)
    self.doneDesc = str
end

function CHALLENGE:GetFinishedDesc()
    return self.doneDesc
end

function CHALLENGE:AddProgress(amt)
    local startProgress = self.progress
    local maxGoal = self:GetMaxGoal()
    self.progress = math.Clamp(self.progress + amt, 0, maxGoal)

    if (self.progress >= self.goal[self.stage] and self.progress ~= maxGoal) then
        self:OnStageComplete()
    elseif (self.progress == maxGoal) then
        self:OnComplete()
    end

    self:CalculateStage()

    if (SERVER and startProgress < self:GetMaxGoal()) then
        self:SaveThink()
    end
end

function CHALLENGE:AddToQueue()
    if (self.player) then
        BATTLEPASS.QueuedChallengeRequests[self.player:AccountID() .. "$_$" .. self.cat .. "$_$" .. self.index] = self.progress
    end
end

function CHALLENGE:Save()
    local cat = self.cat
    local index = self.index

    if (self.player) then
        BATTLEPASS.Database:SaveChallenge(self.player, cat, index)
    end
end

function CHALLENGE:IsComplete()
    return self:GetProgress() >= self:GetMaxGoal()
end

function CHALLENGE:CalculateStage()
    if not istable(self.goal) then return 1 end

    if (self.progress >= self.goal[#self.goal]) then
        self.stage = #self.goal
    end

    for k, v in pairs(self.goal) do
        if v > self.progress then
            self.stage = k
            break
        end
    end
end

function CHALLENGE:IsStageComplete()
    return self:GetProgress() >= self.goal[self.stage]
end

function CHALLENGE:NetworkProgress()
    if CLIENT then return end
    net.Start("BATTLEPASS.SyncChallengeProgress")
    net.WriteString(self.cat)
    net.WriteUInt(self.index, 10)
    net.WriteFloat(self.progress)
    net.WriteUInt(self.player.BattlePass.Owned.progress, 8)
    net.Send(self.player)
end

function CHALLENGE:SetReward(reward)
    self.reward = tonumber(reward) and {reward} or istable(reward) and reward or {10}
end

function CHALLENGE:GetRewardByStage(override)
    return istable(self.reward) and self.reward[override or self.stage] or istable(self.reward) and self.reward[1] or self.reward
end

function CHALLENGE:GetRewardByProgress(progress)
    local goal = self:GetGoalByProgress(progress)

    return istable(self.reward) and self.reward[goal] or self.reward
end

function CHALLENGE:SetGoal(goal)
    self.goal = tonumber(goal) and {goal} or istable(goal) and goal or {10}
end

function CHALLENGE:GetGoal()
    for k, v in pairs(self.goal) do
        if v > self:GetProgress() then return v end
    end

    return self.goal and self.goal[1]
end

function CHALLENGE:GetGoalByProgress(progress)
    for k, v in pairs(self.goal) do
        if v > progress then return v end
    end

    return self.goal and self.goal[1] or 0
end

function CHALLENGE:GetMaxGoal()
    return istable(self.goal) and self.goal[#self.goal] or 10
end

function CHALLENGE:SetIcon(dir)
    self.icon = Material(dir, "smooth")
end

function CHALLENGE:SetInput(tbl)
    self.input = tbl
end

function CHALLENGE:SetProgressDesc(desc)
    self.progressDesc = desc
end

function CHALLENGE:GetProgressDesc()
    return self.progressDesc
end

function CHALLENGE:OnComplete(ply)
    BATTLEPASS:AddProgress(ply or self.player, self.reward[#self.reward])
    self.stage = self.stage + 1

    if (CLIENT) then
        self:AddChallengeNotification()
    end

    self:Remove()
end

function CHALLENGE:OnStageComplete(ply)
    BATTLEPASS:AddProgress(ply or self.player, self.reward[self.stage])
    self.stage = self.stage + 1

    if (CLIENT) then
        self:AddStageNotification(self.stage - 1)
    end
end

function CHALLENGE:AddChallengeNotification()
    local tbl = BATTLEPASS.Pass.challenges[self.cat][self.index]
    local name = tbl.name

    if (not name) then
        name = BATTLEPASS.Challenges[tbl.id]:GetName()
    end

    local msg = "You completed challenge [" .. name .. "] for a reward of " .. (istable(self.reward) and self.reward[#self.reward] or self.reward) .. " stars"
    XeninUI:Notify(msg, LocalPlayer(), 5, XeninUI.Theme.Green)
    chat.AddText(XeninUI.Theme.Accent, "[BATTLE PASS] ", color_white, msg)
end

function CHALLENGE:AddStageNotification(stage)
    local tbl = BATTLEPASS.Pass.challenges[self.cat][self.index]
    local name = tbl.name

    if (not name) then
        name = BATTLEPASS.Challenges[tbl.id]:GetName()
    end

    local msg = "You completed a stage for the challenge [" .. name .. "] for a reward of " .. self:GetRewardByStage(stage) .. " stars"
    XeninUI:Notify(msg, LocalPlayer(), 5, XeninUI.Theme.Green)
    chat.AddText(XeninUI.Theme.Accent, "[BATTLE PASS] ", color_white, msg)
end

ASAPChallenges = ASAPChallenges or {}

function CHALLENGE:AddHook(str, func)
    self.hooks[str] = func
    local uid = self.uid

    hook.Add(str, "ASAP.BP_" .. str .. "_" .. uid, function(...)
        for k, v in pairs(ASAPChallenges[uid] or {}) do
            if not IsValid(k) then
                ASAPChallenges[uid][k] = nil
                continue
            end

            if not v:IsComplete() then
                func(v, k, ...)
            elseif (v:IsComplete()) then
                ASAPChallenges[v.uid][k] = nil
            end
        end
    end)
end

function CHALLENGE:AddTimer(delay, func)
    table.insert(self.timers, {
        delay = delay,
        func = func
    })
end

function CHALLENGE:StopTracking()
    if IsValid(self.player) then
        ASAPChallenges[self.uid][self.player] = nil
    end

    --for k, v in pairs(self.hooks) do
    --hook.Remove(k, "BATTLEPASS_Challenges_" .. self.uid .. self.uniqueid .. self.pid)
    --end
    timer.Remove("BATTLEPASS_Challenges_" .. self.uid .. self.uniqueid .. self.pid)
end

function CHALLENGE:StartTracking()
    for i, v in pairs(self.timers) do
        timer.Create("BATTLEPASS_Challenges_" .. self.uid .. self.uniqueid .. self.pid, v.delay, 0, function(...)
            if (not IsValid(self.player)) then
                self:Remove()

                return
            end

            if (not self:IsComplete()) then
                v.func(self, self.player, ...)
            end
        end)
    end

    for i, v in pairs(self.hooks) do
        if not ASAPChallenges[self.uid] then
            ASAPChallenges[self.uid] = {}
        end

        ASAPChallenges[self.uid][self.player] = self
        --[[
        hook.Add(i, "BATTLEPASS_Challenges_" .. self.uid .. self.uniqueid .. self.pid, function(...)
            if (IsValid(self.player)) then
                if (not self:IsComplete()) then
                    v(self, self.player, ...)
                end
            else
                self:Remove()
            end
        end)
		]]
    end
end

function CHALLENGE:SetUniqueID(id)
    self.uniqueid = id
end

function CHALLENGE:SetPlayer(ply)
    self.player = ply
    self.pid = ply:SteamID64()
end

function CHALLENGE:Remove()
    self:StopTracking()
end

function BATTLEPASS:CreateTemplateChallenge(...)
    local tempTbl = table.Copy(CHALLENGE)
    tempTbl.hooks = {}
    tempTbl.timers = {}
    tempTbl.stage = 1
    tempTbl.progress = 0

    tempTbl.goal = {10}

    table.sort(tempTbl.goal, function(a, b) return a > b end)

    return tempTbl
end

function BATTLEPASS:RegisterChallenge(tbl)
    local id = tbl.uid
    if (not id) then return end
    BATTLEPASS.Challenges[id] = tbl
end